#しゅんごいパスタ
require 'rubygems'
require 'win32ole'
require 'auto_click'
require 'unimidi'
require 'yaml'
class Skullgirls_MIDI
  KEY_SETTING = YAML.load_file('setting.yml')['key_setting']
  GAME_SPEED = YAML.load_file('setting.yml')['game_speed']
  SLEEP_TIME = 0.03
  SCALE_KEY = {
    C:["HP"],
    CS:["LP", "MP", "HP"],
    D: ["LP","HP"],
    DS:["MP", "HP"],
    E: ["LP", "MP"],
    F: ["LP"],
    FS:["MP"],
    G: ["HK"],
    GS:["MK", "HK"],
    A: ["LK", "MK"],
    AS:["LK"],
    B: ["MK"],
    R: ["LK", "MK", "HK"]
  }
  def self.triangle(player,th)
    sleep 0.35
    puts("#{player} triangle")
    if(player == '1p')
      key = KEY_SETTING['1p']
    else
      key = KEY_SETTING['2p']
    end
    key_down(key['DOWN'])
    key_down(key['LP'])
    sleep SLEEP_TIME
    key_up(key['LP'])
    sleep SLEEP_TIME
    key_down(key['LP'])
    sleep SLEEP_TIME
    key_up(key['DOWN'])
    key_up(key['LP'])
  end
  def self.tambourine(player,th)
    
    sleep 0.36
    puts("#{player} tambourine")
    if(player == '1p')
      key = KEY_SETTING['1p']
    else
      key = KEY_SETTING['2p']
    end
    key_down(key['UP'])
    sleep SLEEP_TIME
    key_down(key['LK'])
    sleep SLEEP_TIME
    key_up(key['UP'])
    key_up(key['LK'])
    th.kill
  end

  def self.giant_step(player, gs)
  #ジャイアントステップ
    
    puts("#{player} giant step")
    if(player == '1p')
      key = KEY_SETTING['1p']
      sleep 0.09 #シンバルより発生早いので時間合わせ
      key_down(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['LEFT'])
      sleep SLEEP_TIME
      key_up(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['LK'])
      sleep SLEEP_TIME
      key_up(key['LEFT'])
      key_up(key['LK'])
    else
      key = KEY_SETTING['2p']
      sleep 0.09 #シンバルより発生(ry)
      key_down(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['RIGHT'])
      sleep SLEEP_TIME
      key_up(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['LK'])
      sleep SLEEP_TIME
      key_up(key['RIGHT'])
      key_up(key['LK'])
    end
    gs.kill
  end

  def self.cymbal_clash(player,cl)
  #シンバル
    
    puts("#{player} cymbal clash")
    if(player == '1p')
      key = KEY_SETTING['1p']
      key_down(key['UP'])
      sleep SLEEP_TIME
      key_up(key['UP'])
      key_down(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['LEFT'])
      sleep SLEEP_TIME
      key_up(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['LK'])
      sleep SLEEP_TIME
      key_up(key['LEFT'])
      key_up(key['LK'])
    else
      key = KEY_SETTING['2p']
      key_down(key['UP'])
      sleep SLEEP_TIME
      key_up(key['UP'])
      key_down(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['RIGHT'])
      sleep SLEEP_TIME
      key_up(key['DOWN'])
      sleep SLEEP_TIME
      key_down(key['LK'])
      sleep SLEEP_TIME
      key_up(key['RIGHT'])
      key_up(key['LK'])
    end
    cl.kill
  end

  def self.high_mid_tom(player,th)
    
    sleep 0.20
    puts("#{player} High Tom")
    if(player == '1p')
      key = KEY_SETTING['1p']
    else
      key = KEY_SETTING['2p']
    end
    key_down(key['UP'])
    sleep SLEEP_TIME
    key_down(key['HP'])
    sleep SLEEP_TIME
    key_up(key['UP'])
    key_up(key['HP'])
    th.kill
  end
  def self.low_mid_tom(player,th)
    
    sleep 0.21
    puts("#{player} Mid Tom")
    if(player == '1p')
      key = KEY_SETTING['1p']
    else
      key = KEY_SETTING['2p']
    end
    key_down(key['UP'])
    sleep SLEEP_TIME
    key_down(key['MP'])
    sleep SLEEP_TIME
    key_up(key['UP'])
    key_up(key['MP'])
    th.kill
  end
    def self.low_tom(player,th)
    
    sleep 0.22
    puts("#{player} Low Tom")
    if(player == '1p')
      key = KEY_SETTING['1p']
    else
      key = KEY_SETTING['2p']
    end
    key_down(key['UP'])
    sleep SLEEP_TIME
    key_down(key['LP'])
    sleep SLEEP_TIME
    key_up(key['UP'])
    key_up(key['LP'])
    th.kill
  end
  def self.snare(player,sn)
    
    sleep 0.32
    puts("#{player} snare")
    if(player == '1p')
      key = KEY_SETTING['1p']
      key_down(key['DOWN'])
      key_down(key['MK'])
      sleep SLEEP_TIME
      key_up(key['DOWN'])
      key_up(key['MK'])
    else
      key = KEY_SETTING['2p']
      key_down(key['DOWN'])
      key_down(key['MK'])
      sleep SLEEP_TIME
      key_up(key['DOWN'])
      key_up(key['MK'])
      
    end
    sn.kill
  end
  def self.puf(player,pf)
    
    sleep 0.4
    puts("#{player} puf")
    if(player == '1p')
      key = KEY_SETTING['1p']
      key_down(key['LP'])
      sleep SLEEP_TIME
      key_up(key['LP'])
    else
      key = KEY_SETTING['2p']
      k7mey_down(key['LP'])
      sleep SLEEP_TIME
      key_up(key['LP'])
    end
    pf.kill
  end
  def self.bass(player,bs)
    
    sleep 0.32
    puts("#{player} bass")
    if(player == '1p')
      key = KEY_SETTING['1p']
      key_down(key['LK'])
      sleep SLEEP_TIME
      key_up(key['LK'])
    else
      key = KEY_SETTING['2p']
      key_down(key['LK'])
      sleep SLEEP_TIME
      key_up(key['LK'])
      
    end
    bs.kill
  end
  def self.select()
    
    key = KEY_SETTING['1p']
    key_down(key['SELECT'])
    sleep SLEEP_TIME
    key_up(key['SELECT'])

  end
end
sm = Skullgirls_MIDI.new
shell_obj = WIN32OLE.new("WScript.Shell")
shell_obj.AppActivate("Skullgirls Encore")
shell_obj.AppActivate("Domino")
INPUT_MIDI_DEVICE_NAME = YAML.load_file('setting.yml')['input_midi_device_name']
player = '1p'
input = UniMIDI::Input.find_by_name(INPUT_MIDI_DEVICE_NAME).open
puts %Q{midi受けてビッグバンドの打楽器演奏するツール by KST}
puts "接続完了待機中:#{input.pretty_name}"
loop do
  note = input.gets()[0][:data]
  

  unless note.count == 3
    next
  end
  print "#{note}\n"
  case note[1]
  when 81 #Open Triangle -> Triangle
    ta = Thread.new(player,ta, &Skullgirls_MIDI.method(:triangle))
    player = (player == '1p')? '2p' : '1p'
  when 54 #Tambourine -> JLK
    tr = Thread.new(player,tr, &Skullgirls_MIDI.method(:tambourine))
    player = (player == '1p')? '2p' : '1p'
  when 49 #clash cymbal -> cymbal clash
    cl = Thread.new(player,cl, &Skullgirls_MIDI.method(:cymbal_clash))
    player = (player == '1p')? '2p' : '1p'

  when 48 #High Mid Tom -> JHP
    hmt = Thread.new(player,hmt,&Skullgirls_MIDI.method(:high_mid_tom))
    player = (player == '1p')? '2p' : '1p'

  when 47 #Low Mid Tom -> JMP
    lmt = Thread.new(player,lmt,&Skullgirls_MIDI.method(:low_mid_tom))
    player = (player == '1p')? '2p' : '1p'
  when 45 #Low Tom -> JLP
    lt = Thread.new(player,lt,&Skullgirls_MIDI.method(:low_tom))
    player = (player == '1p')? '2p' : '1p'

  when 38 #Snare
    sn = Thread.new(player,sn,&Skullgirls_MIDI.method(:snare))
    player = (player == '1p')? '2p' : '1p'
  when 37 #puf -> LP
    pf = Thread.new(player,pf,&Skullgirls_MIDI.method(:puf))
    player = (player == '1p')? '2p' : '1p'
  when 36 #bass -> Light giant step
    gs = Thread.new(player,gs,&Skullgirls_MIDI.method(:giant_step))
    player = (player == '1p')? '2p' : '1p'
  when 35 #acoustic bass->LK
    bs = Thread.new(player,bs,&Skullgirls_MIDI.method(:bass))
    player = (player == '1p')? '2p' : '1p'
  when 34 #select
    sc = Thread.new(sc,&Skullgirls_MIDI.method(:select))
  else
    print "\n"
  end
end